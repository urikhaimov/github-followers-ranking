
export const initialState = {
    users: [],
    followers: [],
    sortBy: '',
    currentPage: 1,
    isLoading: false
  };