import FollowersPagination from "./FollowersPagination";
export default FollowersPagination;