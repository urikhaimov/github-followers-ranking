import Sorting from "./Sorting";
export default Sorting;