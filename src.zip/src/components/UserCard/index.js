import UserCard from "./UserCard";

export default UserCard;